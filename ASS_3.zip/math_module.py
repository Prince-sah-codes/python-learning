import math

num = int(input("Enter a number: "))
squareroot= math.sqrt(num)
logarithm = math.log(num)
sine = math.sin(num)
print(f"Square root of given number: {squareroot}")
print(f'Logarithm: {logarithm}')
print(f'Sine: {sine}')